# Risk Adjustment Encounter Modernization — Target Architecture and Plan

**Objective:** Retire the Optum minimum claim format. Generate compliant X12 837 EDRs from a CareOregon-owned data platform, transmit via Optum (or any successor), and close the loop by reconciling CMS responses back to source encounters.
**Prepared for:** Architecture and planning review
**Status:** Draft — renderer language decision (.NET vs Python) open, analysis in Section 3.6

---

## 1. Design principles

1. **The owned asset is the data model, not the file.** The 837 is a renderer over a normalized encounter model. Vendor portability comes from the model, not the format we emit.
2. **Business logic lives where it is testable.** Set-based data logic in Snowflake SQL; conditional document-construction logic in unit-tested application code. Nothing load-bearing lives in visual designers.
3. **Every submission is traceable end to end.** Encounter → file → CMS disposition → risk adjustment outcome is one queryable chain, by design, from day one.
4. **No new platforms.** Snowflake and Azure, with application code in a language the team can operate long-term. Databricks is not in this pipeline (see 9.3).

---

## 2. Reference architecture

```
 ON-PREM SQL SOURCES
        │  (ingestion: ADF / Snowflake connector)
        ▼
┌───────────────────────────── SNOWFLAKE ─────────────────────────────┐
│  L1 RAW            landed source data, unmodified, auditable        │
│  L2 CONFORMED      normalized encounter model (the owned asset)     │
│                    claims, members, providers, coverage, capitation │
│  L3 SUBMISSION     flat, decision-free 837-ready records            │
│                    + submission lifecycle spine (CLM01, ICN, status)│
│  L4 RESPONSE       parsed TA1 / 999 / 277CA / MAO-002 content       │
│                    keyed back to L3 identities                      │
│  ANALYTICS         reads across L2–L4: acceptance rates, compliance │
│                    metrics, risk adjustment tie-back                │
└──────────────┬──────────────────────────────▲───────────────────────┘
               │ L3 extract                    │ parsed responses
               ▼                               │
┌─────────────── AZURE APPLICATION TIER (.NET or Python) ────┴───────┐
│  837 RENDERER (Function / Container App)                            │
│    • reads L3, builds segments, loops, envelopes (ISA/GS/ST)        │
│    • control numbers persisted transactionally                      │
│    • pre-submission validation: edit-spreadsheet rules as tests     │
│  RESPONSE PARSERS                                                   │
│    • TA1, 999, 277CA (X12) and MAO-002/004 (fixed-width) → L4       │
│  ORCHESTRATION: Azure Data Factory or Durable Functions            │
│    schedule → extract → render → validate → transmit → poll → parse │
└──────────────┬──────────────────────────────▲──────────────────────┘
               │ SFTP put                      │ SFTP get
               ▼                               │
        ┌─────────────────── OPTUM ────────────┴───────┐
        │  pass-through transmission only (target state) │
        └─────────────────── CMS EDFES/EDPS ────────────┘
```

---

## 3. Component decisions and rationale

### 3.1 Snowflake — data logic (L1–L4)

All set-shaped work: source conformance, encounter derivation, capitation determination, code selection, void/replace decisioning, service-line assembly. Output of L3 is the contract with the renderer: **every field resolved, every business decision made, nothing left to derive downstream.**

Test: if a rule decides *what data* goes in the encounter, it lives here. Testable with SQL assertions in CI (dbt tests or equivalent).

### 3.2 Application renderer — structural logic (language open, see 3.6)

Builds the 837 from L3 records: loop presence by encounter type, situational segments, the optional-loop rule (populate a situational loop → all its required elements become mandatory), CN101 capitation flags at header vs line, PWK values by situation, default NPI/EIN selection, diagnosis pointers, HIPPS handling, ambulance loops 2310E/F.

**Deliberate decision: the renderer emits the complete X12 file, envelopes included.** ISA/IEA, GS/GE, ST/SE are trivial fixed structures; control numbers are a persisted counter (small Azure SQL table or Snowflake sequence, incremented transactionally per interchange). This is the decision that removes the Integration Account, the maps, and the BizTalk-shaped tooling entirely.

Writing X12 is string assembly over a known structure — generating is far easier than parsing. A thin internal library (Segment, Loop, Interchange abstractions, on the order of hundreds of lines) is sufficient in either language.

### 3.3 Logic Apps — demoted to plumbing, or removed

Logic Apps' X12 capability (Integration Account, agreements, maps) is BizTalk's descendant and shares its failure modes — visual logic, painful diffs, miserable troubleshooting. **None of it is needed** once the renderer owns envelopes.

What remains is file movement: SFTP put/get with Optum, retries, alerts. Use whichever is operationally cheapest — a Logic Apps SFTP connector with zero maps, an Azure Function with an SFTP client, or ADF's SFTP activity. Commodity choice, not architectural.

### 3.4 Response parsers

TA1/999/277CA are small, well-specified X12 acknowledgements; MAO-002 and MAO-004 are fixed-width layouts. Parse to structured rows, load to L4 keyed on CLM01 / ICN / control numbers. Same repo, same test discipline as the renderer.

### 3.5 Orchestration — ADF or Durable Functions

Scheduled pipeline: extract L3 delta → render → validate → transmit → record submission → poll for acknowledgements → parse → update lifecycle status → alert on rejects. ADF if the team prefers configuration; Durable Functions if code. Pick one and standardize.

### 3.6 Renderer language: .NET vs Python

The architecture is identical either way. The choice is about the team that builds and operates it, not the design. Both columns assume the same non-negotiables: version control, CI, unit tests, typed models for the L3 contract.

| Dimension | .NET 8 (C#) | Python 3.12 |
|---|---|---|
| Type safety for X12 assembly | Compile-time; wrong field/type caught at build. Strongest guard against silent structural bugs | Runtime by default; recovered substantially with pydantic models + mypy in CI — **must be mandated, not optional** |
| Unit testing | xUnit/NUnit — mature | pytest — equally mature, arguably more ergonomic |
| Fixed-width report parsing (MAO-002/004) | Fine | Slightly more natural; strong string/struct tooling |
| X12/EDI library ecosystem | Richer (commercial healthcare EDI libraries; BizTalk-world migration target) | Thinner and older (e.g. pyx12, parse-oriented); expect to hand-roll generation — acceptable either way |
| Azure hosting | Functions / Container Apps — first-class | Functions / Container Apps — first-class |
| Long-lived service ergonomics | Strong: DI, config, logging conventions standard | Equally achievable; conventions must be chosen and enforced rather than inherited |
| Performance | More headroom; irrelevant at MA-plan encounter volume — batch generation is I/O-bound either way | Entirely sufficient |
| **Current team skills** | **Not present on the team today** — would require hiring or training; slows Phase 2–3 and concentrates 2 a.m. operability risk in few hands | **Present** — team can build and, critically, operate and debug it |
| Hiring market fit (if growing team) | Deep enterprise-healthcare pool | Deep general pool; healthcare-EDI-specific candidates skew .NET |
| Risk profile | Technical risk lowest, delivery/people risk highest | Delivery/people risk lowest; technical risk managed by mandated typing + rule-pack tests |

**Decision guidance:** skills availability normally dominates for a system operated over years — a language the team cannot debug in production is a liability regardless of its merits. If Python is selected, three conditions should be written into the definition of done: (1) pydantic models define the L3 record contract, (2) mypy passes in CI with strict settings on the renderer package, (3) the edit-spreadsheet rule pack runs as a blocking pre-submission gate. Those three recover most of what the compiler would otherwise provide. If .NET is selected despite the skills gap, the plan must fund the gap explicitly (hire or train) and Phase 2 duration should be extended by 3–4 weeks.

**One guardrail either way:** the renderer runs in Azure Functions or Container Apps, not as a Databricks job. Databricks is a Python runtime, and the suggestion will come up — but it couples a transactional pipeline to an analytics platform's scheduler and cost model for no benefit.

---

## 4. The submission lifecycle spine (the part that makes analytics work)

Designed into L3 from day one:

| Element | Rule |
|---|---|
| **Encounter identity** | Deterministic internal key from source claim identity — stable across regenerations |
| **CLM01** | Derived from encounter identity + attempt sequence. Echoed back on 277CA/MAO-002; the join key for everything |
| **ICN** | CMS-assigned on acceptance; persisted against the encounter. Mandatory for any replace (CLM05-3='7') or void ('8'), which reference it in REF*F8 |
| **File identity** | ISA13/GS06 control numbers per submission, so TA1/999 rejects map to the exact file and batch |
| **Status model** | GENERATED → TRANSMITTED → TA1_ACK → 999_ACK → 277CA_ACCEPTED/REJECTED → EDPS_ACCEPTED/REJECTED (MAO-002) → [REPLACED / VOIDED] |
| **Attempt chain** | Every regeneration/resubmission is a new attempt row linked to the same encounter; nothing is overwritten |

With this spine, "tie responses back" is a join, and CMS's compliance metrics (report-card thresholds) become standing queries run before CMS runs them.

---

## 5. Batching and file rules (configuration, not code)

From the Submission and Processing Guide: file size and encounters-per-contract caps (2,000/contract in Tier II), sequential upload timing, the 13-month post-service-year window, separate Payer IDs by record type (institutional 80881 / professional 80882 / DMEPOS 80887) driving separate functional groups, and end-of-year load-spreading (the 27%-in-last-two-months compliance metric). The batcher reads these as config so guide revisions don't require code changes.

---

## 6. Validation strategy — find rejects before CMS does

1. **Unit tests** on structural rules, built from Chapter 3 / Appendix 3A scenarios.
2. **CMS 5010 edit spreadsheets encoded as a pre-submission rule pack** — every file passes through it; a would-be reject never leaves the building. Highest-ROI component in the project.
3. **EDS Test Case Specifications** as acceptance fixtures.
4. **Parallel run:** generate 837s from the same source data still feeding the Optum flat file; diff against what Optum transmits. Every difference is either our defect or undocumented Optum logic — both must be found before cutover.
5. **Tier II environment** (ISA15='T', ISA01='03', ISA02='8888888888') for end-to-end rehearsal including acknowledgement handling.

---

## 7. Phasing overview

| Phase | Scope | Exit criteria (definition of done) |
|---|---|---|
| **0. Discovery** | Optum mapping spec + enrichment inventory; pass-through transmission confirmation; current guide/edit-spreadsheet versions; TR3 licenses; language decision | All unknowns named; Optum spec in hand; language decided and conditions accepted |
| **1. Foundation** | L1/L2 in Snowflake; encounter identity + lifecycle spine schema | Conformed model populated; row counts reconciled to source |
| **2. Renderer core** | L3 model; renderer for 837-P happy path incl. envelopes; test harness; rule pack v1 | Valid 837-P passing internal rule pack |
| **3. Full rules** | 837-I; DME; capitation, defaults, PWK, CRRs, replace/void; response parsers + L4 | Tier II end-to-end pass including acknowledgements |
| **4. Parallel run** | Dual-generate against live volume; diff vs Optum output; burn down differences | Sustained match rate at agreed threshold across ≥2 monthly cycles |
| **5. Cutover** | Optum to pass-through transmission (no transformation); retire flat-file mapping; migrate ICN history | First production cycle fully reconciled in L4 |
| **6. Analytics** | Compliance-metric dashboards; MAO-004 risk adjustment tie-back | Report-card metrics self-computed and matching CMS's |

---

## 8. High-level task plan with timelines

**Assumptions:** 2 data engineers (Snowflake), 2 application engineers (renderer/parsers), 1 BA (mapping), shared QA, ~50% PM/architect (you). Durations are working estimates for scoping, not commitments; Phase 0 vendor response time is the least controllable input. Week numbers assume phases overlap as noted.

| # | Phase | Task | Owner | Duration | Depends on | Definition of done |
|---|---|---|---|---|---|---|
| 1 | 0 | Request Optum mapping spec, enrichment/edit inventory, pass-through transmission terms (submitter-generated 837s transmitted without modification), connectivity details | PM + BA | 1 wk to issue; 3–4 wks vendor turnaround | — | Written responses received |
| 2 | 0 | Pull current Submission & Processing Guide, 5010 edit spreadsheets, test case specs from CSSC; purchase TR3-I/TR3-P licenses | BA | 2 wks | — | Current versions in repo; licenses active |
| 3 | 0 | Renderer language decision (.NET vs Python) per §3.6 | Dilip + team | 1 wk | — | Decision recorded with conditions (typing gates or skills funding) |
| 4 | 0 | Confirm denied-claim encounters are in today's feed; size gap if not | BA + data eng | 2 wks | — | Completeness position documented |
| 5 | 0 | Locate ICN history in current process; assess extractability | Data eng | 2 wks | — | ICN migration approach agreed |
| 6 | 1 | Ingest on-prem SQL sources to Snowflake L1 | Data eng ×2 | 4 wks | — (parallel to Phase 0) | All sources landing on schedule; counts reconciled |
| 7 | 1 | Design + build L2 conformed encounter model | Data eng ×2 | 5 wks | Task 6 (partial overlap) | Model populated; dbt tests green; source reconciliation signed off |
| 8 | 1 | Design lifecycle spine schema (identity, CLM01 derivation, ICN store, status model) | Data eng + app eng | 2 wks | Task 7 start | Schema reviewed and approved |
| 9 | 2 | Build L3 submission model for professional encounters | Data eng + BA | 4 wks | Tasks 7, 8 | L3 rows complete and decision-free for 837-P scope |
| 10 | 2 | Appendix 3A field mapping — professional | BA | 4 wks (parallel with 9) | Task 2 | Mapping workbook approved |
| 11 | 2 | Renderer core: segment/loop library, envelopes, control numbers, 837-P happy path | App eng ×2 | 6 wks | Tasks 3, 9 | Valid 837-P generated from L3; unit tests green |
| 12 | 2 | Edit-spreadsheet rule pack v1 (professional edits) | App eng + QA | 4 wks (overlaps 11) | Task 2 | Rule pack blocks known-bad fixtures; wired into pipeline |
| 13 | 3 | L3 + mapping + renderer for institutional (837-I), incl. HIPPS | Data eng, BA, app eng | 6 wks | Phase 2 exit | Valid 837-I passing rule pack |
| 14 | 3 | DME handling; capitation rules; default NPI/EIN; PWK situations | App eng + BA | 4 wks (overlaps 13) | Task 11 | Scenario test suite green |
| 15 | 3 | Replace/void + CRR construction against ICN spine | App eng | 3 wks | Tasks 5, 13 | Replace/void/CRR fixtures pass Tier II |
| 16 | 3 | Response parsers (TA1, 999, 277CA, MAO-002/004) + L4 loads | App eng | 4 wks (overlaps 13–15) | Task 8 | Sample acknowledgement files parsed and joined to L3 |
| 17 | 3 | Orchestration pipeline end to end; alerting on rejects | App eng + data eng | 3 wks | Tasks 11, 16 | Scheduled run completes unattended in Tier II |
| 18 | 3 | Tier II end-to-end certification rehearsal | QA + all | 3 wks | Tasks 13–17 | Tier II pass incl. acknowledgement round trip |
| 19 | 4 | Parallel run cycle 1: dual-generate, diff vs Optum output, classify differences | All | 4 wks | Phase 3 exit; Task 1 | Difference inventory triaged (our defect vs Optum logic) |
| 20 | 4 | Burn down differences; parallel run cycle 2 (+3 if needed) | All | 4–8 wks | Task 19 | Match rate ≥ agreed threshold, 2 consecutive cycles |
| 21 | 5 | ICN history migration into spine | Data eng | 2 wks | Tasks 5, 20 | Historical ICNs queryable; replace/void tested against them |
| 22 | 5 | Cutover: Optum in pass-through transmission mode; first production submission via new pipeline | All | 2 wks | Tasks 20, 21 | Production cycle accepted; L4 fully reconciled |
| 23 | 5 | Hypercare + decommission flat-file mapping | All | 3 wks | Task 22 | Two clean cycles; old mapping retired |
| 24 | 6 | Compliance-metric dashboards (report-card thresholds) | Data eng | 3 wks | Task 22 | Metrics match CMS report card |
| 25 | 6 | MAO-004 risk adjustment tie-back analytics | Data eng + BA | 3 wks | Task 24 | Encounter → RA-eligible diagnosis lineage queryable |

**Milestone view (elapsed, with overlaps):**

| Milestone | Target |
|---|---|
| M1 — Discovery complete, language decided | End of week 6 |
| M2 — Foundation (L1/L2 + spine) done | End of week 10 |
| M3 — First valid 837-P through rule pack | End of week 16 |
| M4 — Tier II certification rehearsal passed | End of week 28 |
| M5 — Parallel run threshold met | Week 36–40 |
| M6 — Production cutover complete | Week 40–44 |
| M7 — Closed-loop analytics live | Week 46 |

**Overall: roughly 10–11 months elapsed**, with the dominant uncertainties being Optum's responsiveness (Task 1), the size of the difference burn-down (Task 20), and any completeness gap surfaced by Task 4. If .NET is chosen against current skills, add 3–4 weeks to Phase 2 and revisit M3 onward.

---

## 9. Explicit non-choices

**9.1 Logic Apps Integration Account / maps** — rejected. Rebuilds the BizTalk pattern; renderer-owned envelopes make it unnecessary with a single trading partner.
**9.2 FHIR as the submission format** — rejected. CMS EDS accepts X12 837 only; FHIR adds a lossy hop and a vendor-proprietary profile dependency.
**9.3 Databricks in this pipeline** — rejected. Nothing here is code-shaped-at-scale or ML. (Databricks remains appropriate elsewhere — risk models, clinical-text NLP.)
**9.4 Regenerating history through the new pipe at cutover** — decide deliberately; prior submissions carry ICNs from the old path, and replace/void must reference those ICNs regardless of origin.

---

## 10. Principal risks

| Risk | Mitigation |
|---|---|
| Undocumented Optum enrichment lost at cutover | Phase 0 spec demand + parallel-run diffing |
| CMS response semantics differ once Optum stops shielding rejects | Parsers + Tier II rehearsal before production; 999-level rejects alert as our defects |
| Guide/edit-spreadsheet revisions mid-build | Batching + rule pack as config; named owner watching CSSC releases |
| ICN continuity across cutover | Task 21 before first production replace/void |
| End-of-year volume compression breaching the 27% metric | Steady scheduled submission from cutover day one |
| Language decision drift (Python without typing discipline, or unfunded .NET skills gap) | §3.6 conditions written into definition of done |
| Scope creep into chart-review sourcing workflows | CRR *construction* is in scope (Task 15); chart-review sourcing is a separate program |

---

## 11. Open questions for Phase 0

1. Optum: full mapping spec, enrichment/edit inventory, pass-through transmission support and pricing (837s forwarded to CMS without modification), connectivity, handling of in-flight ICNs at transition.
2. Current guide + edit spreadsheet versions from CSSC; TR3-I/TR3-P license status.
3. Does today's flat-file feed include denied-claim encounters (required by CMS regardless of payment status)? If not, size the gap.
4. CRR volume and current sourcing process.
5. Where ICN history lives today, and can it be extracted.
6. Renderer language: .NET or Python, per §3.6, with the corresponding conditions accepted.
