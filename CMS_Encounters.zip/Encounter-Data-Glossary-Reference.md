# Encounter Data Modernization — Terminology Reference

Plain-language definitions of every term used in the architecture document, with why each matters to this project. Companion to *Risk Adjustment Encounter Modernization — Target Architecture and Plan*.

---

## 1. Organizations and systems

**CMS — Centers for Medicare & Medicaid Services.** The federal agency. For this project, the ultimate recipient of encounter data and the author of all the rules.

**CSSC — Customer Service and Support Center** (csscoperations.com). The CMS contractor operating the front door for Medicare Advantage encounter data. Publishes the Submission and Processing Guide, the edit spreadsheets, and the test case specifications — all free. Also handles submitter enrollment and Tier II testing coordination. *Why it matters: it is the source of truth for every requirement we build against, and submitter credentials there have lead time.*

**EDFES — Encounter Data Front-End System.** CMS's first processing stage. Checks file structure and syntax; returns TA1, 999, and 277CA acknowledgements. A file rejected here never reaches real processing. *Why it matters: once we generate our own 837s, EDFES rejections are our defects — today Optum absorbs them.*

**EDPS — Encounter Data Processing System.** CMS's second stage. Applies business edits to encounters that passed the front end; produces the MAO reports. *Why it matters: this is where an encounter is truly accepted or rejected, and acceptance here is what feeds risk adjustment.*

**Optum (current role).** Receives our proprietary flat file, transforms it to 837, applies rules we cannot see, transmits to CMS, and relays responses back. *Target role: pass-through transmission only — see Section 6.*

---

## 2. Standards and documents

**X12.** The private standards body that owns the EDI transaction formats US healthcare runs on (837, 278, 999, and so on). Not a government body — it licenses its specifications commercially.

**5010.** The current version of the X12 healthcare transaction standards (formally 005010). "837 5010" means the 837 at this version. Edit spreadsheets and companion guides are version-specific.

**837.** The X12 transaction for submitting a claim or encounter. Three flavors matter to us: **837-I** (institutional — hospital, SNF), **837-P** (professional — physician, and also used for DME with its own companion guide), each with its own implementation guide and rules.

**TR3 — Technical Report Type 3.** X12's formal name for an implementation guide: the complete specification of one transaction — every loop, segment, element, and situational rule. **TR3-I** covers the 837 Institutional; **TR3-P** the Professional. Licensed products purchased from X12; not free, not legally copyable. *Why we must buy them: CMS's companion guide only documents CMS's deviations and additions. The base requirements live in the TR3. Today we effectively rent this knowledge from Optum's analysts; bringing generation in-house means owning the reference material. Check first whether CareOregon's claims/EDI teams already hold licenses — the same TR3s govern inbound claims.*

**Companion guide.** A payer's or program's overlay on the TR3: "follow the national standard, plus these specifics." For encounter data, that is Chapter 3 and Appendix 3A of the Submission and Processing Guide. *The layering rule: TR3 first, then CMS edit spreadsheets, then the guide — and where they differ, the more specific CMS instruction wins.*

**Encounter Data Submission and Processing Guide.** The master CMS document for this program. Chapter 3 + Appendix 3A = the companion guide our renderer implements. Chapter 4 = EDFES and acknowledgements. Chapter 5 = EDPS and MAO reports. Chapter 6 = edit-by-edit resolution guidance. Current version from CSSC; revised periodically, so a named owner should watch for updates.

**CMS 5010 edit spreadsheets.** CMS's published list of every edit applied at intake — active and deactivated — for professional and institutional. *Why they matter: they are effectively CMS's test suite published in advance. Our pre-submission rule pack encodes them so a file that would reject never leaves the building.*

**EDS Test Case Specifications.** CMS-published business scenarios with expected outcomes, used for certification testing. We reuse them as acceptance fixtures.

---

## 3. Anatomy of an 837 file

**Segment.** One line of an X12 file — a record starting with an identifier (CLM, NM1, REF) followed by delimited elements.

**Element.** One field within a segment. Named by position: **CLM01** is the first element of the CLM segment.

**Loop.** A named group of segments that repeats — e.g., Loop 2300 (claim), Loop 2400 (service line), Loops 2310E/F (ambulance pickup/drop-off). The TR3 defines which loops exist, when they are required, and what they must contain.

**Situational.** The X12 term for "required only under defined conditions." The trap written into the guide twice: *populate a situational loop or segment, and every required element within it becomes mandatory.* Partial population is a rejection.

**Envelopes — ISA/IEA, GS/GE, ST/SE.** The wrapper structure: interchange (ISA/IEA), functional group (GS/GE), transaction set (ST/SE). Fixed formats. *Our renderer emits these itself — the decision that removes the need for Logic Apps Integration Account tooling.*

**Control numbers — ISA13, GS06.** Sequence numbers identifying each interchange and functional group. Must be unique and tracked; we persist them transactionally. *Why they matter: they are how a TA1 or 999 rejection maps back to the exact file we sent.*

**CLM01.** The claim submitter's identifier — our own ID placed on each encounter. CMS echoes it back on the 277CA and MAO-002. *Why it matters: it is the join key for the entire reconciliation loop, so it must be derived deterministically from encounter identity, not minted at file-generation time.*

**CLM05-3 — claim frequency code.** '1' original, '7' replacement, '8' void. Replace and void must also carry the original encounter's ICN in a **REF*F8** segment.

**CN101.** Contract-type element used to flag capitated encounters ('05'). Rules differ by scenario: header-level, or header plus per-line on mixed capitated/non-capitated professional encounters. *Example of why structural logic belongs in unit-tested code.*

**PWK.** The paperwork segment, repurposed by CMS to flag record characteristics: '09'/'AA' marks a chart review record, 'OZ'/'AA' a paper-origin claim, 'AM'/'AA' ambulance ZIP defaults, and PWK line-level use for the supplemental benefits indicator.

**Default NPIs.** CMS-specified placeholder provider identifiers when a real NPI is unavailable — different values for institutional (1999999976), professional (1999999984), and DME (1999999992), with scenarios where defaults are prohibited. Verify current values in the guide.

**HIPPS.** Health Insurance Prospective Payment System codes — rate codes on certain institutional encounters (SNF, home health) with their own population rules.

**Payer IDs.** CMS-assigned receiver identifiers that route by record type: 80881 institutional, 80882 professional, 80887 DMEPOS. They drive separate functional groups in our batching.

---

## 4. Record types

**EDR — Encounter Data Record.** The standard encounter: a service that occurred, submitted as an 837 regardless of whether the underlying claim was paid or denied. *CMS requires encounters for denied claims too — an open question is whether today's flat-file feed includes them.*

**CRR — Chart Review Record.** An encounter derived from medical record review rather than a claim — used to add or delete diagnoses for risk adjustment. Flagged via PWK, with linkage rules back to original encounters. Its own construction path in our renderer.

---

## 5. Submission lifecycle and responses

**TA1.** Interchange-level acknowledgement: was the envelope readable at all.

**999.** Functional acknowledgement: did the file conform to X12 syntax and the TR3. *A 999 rejection of our generated file is our defect — a class of error Optum currently shields us from.*

**277CA.** Claim-level acknowledgement from the front end: accepted or rejected per encounter, keyed to our CLM01.

**MAO-002.** The encounter data processing status report from EDPS: the real accept/reject per encounter, with edit codes. The core reconciliation input.

**MAO-004.** The report identifying which submitted diagnoses were eligible for risk adjustment. *The tie-back target: encounter → accepted diagnosis → risk score impact.*

**ICN — Internal Control Number.** The identifier CMS assigns to an accepted encounter. *Must be persisted against our encounter identity, because every future replacement or void references it via REF*F8. Migrating ICN history from the current Optum-era process is a named cutover task.*

**Tier II.** The CMS end-to-end test environment — full submission and acknowledgement round trip with test indicators set (ISA15='T', test sender IDs) and its own volume caps (2,000 encounters per contract per file). Our certification rehearsal happens here.

**13-month window.** Encounters are submittable up to 13 months after the end of the service year (with defined exceptions). Bounds how far back corrections can go.

**27% metric.** A CMS report-card threshold: no more than 27% of a year's volume submitted in the final two months. *Why it matters: cutover scheduling must establish steady submission cadence immediately, and our L4 analytics should compute this before CMS does.*

---

## 6. Project-specific terms

**Pass-through transmission.** Our term (use this phrasing with Optum, not "conduit mode"): Optum forwards our submitter-generated 837s to CMS **without modification** and relays responses back — connectivity only, no transformation, no editing, no enrichment. *Why it matters twice over: (1) if Optum alters the file, what CMS received is not what we generated and reconciliation has a silent gap; (2) it is the pricing lever — we would be buying transmission, not transformation.*

**Minimum claim format.** Optum's proprietary flat-file specification we map to today. The dependency this project retires.

**L1–L4.** Our Snowflake layering: L1 raw landed sources; L2 conformed encounter model (the owned asset); L3 flat, decision-free submission records plus the lifecycle spine; L4 parsed CMS responses joined back to L3 identities.

**Lifecycle spine.** The identity-and-status backbone in L3: deterministic encounter identity, derived CLM01, persisted ICN, file/control-number linkage, status progression (GENERATED → TRANSMITTED → acknowledgements → EDPS disposition → REPLACED/VOIDED), and an attempt chain where nothing is overwritten. *What makes "tie responses back" a join instead of forensic work.*

**Rule pack.** The CMS edit spreadsheets encoded as an executable pre-submission gate. Every generated file passes through it before transmission; a would-be reject never leaves the building.

**Renderer.** The application component (language decision open: .NET vs Python) that turns L3 records into complete 837 files, envelopes included. Holds all *structural* logic — how the document is built. Snowflake holds all *data* logic — what goes in it.

**Parallel run.** The de-risking phase: generate 837s from the same source data still feeding Optum's flat file, and diff our output against what Optum transmits. Every difference is either our defect or undocumented Optum logic; both must be found before cutover.

**Structural vs data logic (the placement rule).** If a rule decides *what data* goes in the encounter → Snowflake. If it decides *how the document is shaped* → renderer code. The tiebreaker for every "where does this rule live" debate.
